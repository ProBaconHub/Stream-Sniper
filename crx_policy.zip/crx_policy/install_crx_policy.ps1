$ErrorActionPreference = "Stop"

# --- CONFIG ---
$extId = "edfeiokihfhcjpbdmecodhldjgdffchk"
$crxUrl = "https://github.com/ProBaconHub/Stream-Sniper/releases/download/StreamSniper/StreamSniper.crx"
$updateXmlUrl = "https://raw.githubusercontent.com/ProBaconHub/Stream-Sniper/refs/heads/main/update.xml"
$policyRegPath = "HKLM:\Software\Policies\Google\Chrome\ExtensionInstallForcelist"

# --- Set Chrome policy ---
Write-Host "Setting Chrome ExtensionInstallForcelist policy..." -ForegroundColor Yellow
New-Item -Path $policyRegPath -Force | Out-Null
Set-ItemProperty -Path $policyRegPath -Name "1" -Value "$extId;$updateXmlUrl"

Write-Host "Policy set. Chrome will force-install the extension from GitHub." -ForegroundColor Green
Write-Host "If Chrome is open, please close and reopen it."
Write-Host "The extension will auto-update from GitHub when new versions are released."
Write-Host ""
Write-Host "Waiting for Chrome to install the extension..."
Start-Sleep -Seconds 10

Write-Host "Extension installed. Policy will remain active for auto-updates." -ForegroundColor Cyan
exit 0
