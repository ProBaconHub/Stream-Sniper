$ErrorActionPreference = "Stop"

# --- CONFIG FR ---
$crxName = "StreamSniper.crx"
$updateXmlName = "update.xml"
$webPort = 8765
$policyRegPath = "HKLM:\Software\Policies\Google\Chrome\ExtensionInstallForcelist"
$extId = "edfeiokihfhcjpbdmecodhldjgdffchk"

$scriptPath = Split-Path -Parent $MyInvocation.MyCommand.Path
$webRoot = Join-Path $scriptPath "crx_policy"

# --- Check CRX ---
if (!(Test-Path (Join-Path $webRoot $crxName))) {
    Write-Host "[ERROR] CRX file not found. Place $crxName in $webRoot." -ForegroundColor Red
    exit 1
}

# --- Build update.xml ---
$updateXml = @"<?xml version=\"1.0\" encoding=\"UTF-8\"?>
<gupdate xmlns=\"http://www.google.com/update2/response\">
  <app appid=\"$extId\">
    <updatecheck codebase=\"http://localhost:$webPort/$crxName\" version=\"1.0.0\" />
  </app>
</gupdate>
"@
Set-Content -Path (Join-Path $webRoot $updateXmlName) -Value $updateXml -Encoding UTF8

# --- Build localhost server ---
Write-Host "Starting localhost web server on port $webPort..." -ForegroundColor Yellow
$listener = New-Object System.Net.HttpListener
$listener.Prefixes.Add("http://localhost:$webPort/")
$listener.Start()

$serverJob = Start-Job -ScriptBlock {
    param($webRoot, $listener)
    while ($listener.IsListening) {
        $context = $listener.GetContext()
        $request = $context.Request
        $response = $context.Response
        $path = $request.Url.LocalPath.TrimStart('/').Replace('/', '\')
        $file = Join-Path $webRoot $path
        if (Test-Path $file) {
            $bytes = [System.IO.File]::ReadAllBytes($file)
            $response.OutputStream.Write($bytes, 0, $bytes.Length)
        } else {
            $response.StatusCode = 404
        }
        $response.Close()
    }
} -ArgumentList $webRoot, $listener

Start-Sleep -Seconds 2

# --- Set Chrome policy ---
Write-Host "Setting Chrome ExtensionInstallForcelist policy..." -ForegroundColor Yellow
New-Item -Path $policyRegPath -Force | Out-Null
Set-ItemProperty -Path $policyRegPath -Name "1" -Value "$extId;http://localhost:$webPort/$updateXmlName"

Write-Host "Policy set. Chrome will force-install the extension from localhost." -ForegroundColor Green
Write-Host "If Chrome is open, please close and reopen it."
Write-Host "Waiting for extension to install..."
Start-Sleep -Seconds 5

# --- Silent cleanup ---
$listener.Stop()
Stop-Job $serverJob | Out-Null
Remove-Job $serverJob | Out-Null
Remove-Item (Join-Path $webRoot $updateXmlName) -ErrorAction SilentlyContinue
Write-Host "Extension installed. Cleanup complete." -ForegroundColor Cyan
exit 0
