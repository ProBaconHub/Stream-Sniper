# PowerShell script to force-install a Chrome extension via policy
# 1. Hosts the CRX and update.xml on localhost
# 2. Sets registry policy to force-install the extension
# 3. Cleans up on exit

$ErrorActionPreference = "Stop"

# --- CONFIG ---
$crxName = "StreamSniper.crx"
$updateXmlName = "update.xml"
$webPort = 8765
$policyRegPath = "HKLM:\Software\Policies\Google\Chrome\ExtensionInstallForcelist"
$extId = "YOUR_EXTENSION_ID" # Replace with your extension's real ID

$scriptPath = Split-Path -Parent $MyInvocation.MyCommand.Path
$webRoot = Join-Path $scriptPath "crx_policy"

# --- Check CRX ---
if (!(Test-Path (Join-Path $webRoot $crxName))) {
    Write-Host "[ERROR] CRX file not found. Place $crxName in $webRoot." -ForegroundColor Red
    exit 1
}

# --- Generate update.xml ---
$updateXml = @"<?xml version=\"1.0\" encoding=\"UTF-8\"?>
<gupdate xmlns=\"http://www.google.com/update2/response\">
  <app appid=\"$extId\">
    <updatecheck codebase=\"http://localhost:$webPort/$crxName\" version=\"1.0.0\" />
  </app>
</gupdate>
"@
Set-Content -Path (Join-Path $webRoot $updateXmlName) -Value $updateXml -Encoding UTF8

# --- Start localhost server ---
Write-Host "Starting localhost web server on port $webPort..." -ForegroundColor Yellow
$listener = New-Object System.Net.HttpListener
$listener.Prefixes.Add("http://localhost:$webPort/")
$listener.Start()

$serverJob = Start-Job -ScriptBlock {
    param($webRoot, $listener)
    while ($listener.IsListening) {
        $context = $listener.GetContext()
        $request = $context.Request
        $response = $context.Response
        $path = $request.Url.LocalPath.TrimStart('/').Replace('/', '\')
        $file = Join-Path $webRoot $path
        if (Test-Path $file) {
            $bytes = [System.IO.File]::ReadAllBytes($file)
            $response.OutputStream.Write($bytes, 0, $bytes.Length)
        } else {
            $response.StatusCode = 404
        }
        $response.Close()
    }
} -ArgumentList $webRoot, $listener

Start-Sleep -Seconds 2

# --- Set Chrome policy ---
Write-Host "Setting Chrome ExtensionInstallForcelist policy..." -ForegroundColor Yellow
New-Item -Path $policyRegPath -Force | Out-Null
Set-ItemProperty -Path $policyRegPath -Name "1" -Value "$extId;http://localhost:$webPort/$updateXmlName"

Write-Host "Policy set. Chrome will force-install the extension from localhost." -ForegroundColor Green
Write-Host "If Chrome is open, please close and reopen it."
Write-Host "Wait for extension to appear in chrome://extensions/."
Write-Host ""

Write-Host "Press Enter to stop server and clean up..."
Read-Host

# --- Cleanup ---
$listener.Stop()
Stop-Job $serverJob | Out-Null
Remove-Job $serverJob | Out-Null
Remove-ItemProperty -Path $policyRegPath -Name "1" -ErrorAction SilentlyContinue
Remove-Item (Join-Path $webRoot $updateXmlName) -ErrorAction SilentlyContinue
Write-Host "Cleanup complete. Policy removed and server stopped." -ForegroundColor Cyan
Write-Host "You may now remove the extension manually from Chrome if needed."
Write-Host ""
Write-Host "Installer finished. Press any key to exit..."
$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
